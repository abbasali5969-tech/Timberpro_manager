TimberPro Manager - Flutter starter

What is included:
- pubspec.yaml dependencies
- lib/ folder with source code (main.dart, db helper, models, providers, screens)
- Seeded demo data (Teak, Mango, sample door)

Important next steps to run:
1. Ensure you have Flutter installed: https://flutter.dev/docs/get-started/install
2. Extract this project to a folder.
3. From the project root run:
   flutter create .
   flutter pub get
4. (Optional) Open the project in Android Studio to generate Android/iOS platform folders.
5. Run on device:
   flutter run
6. To build signed APK follow the instructions I provided earlier (create keystore, add android/key.properties, then run `flutter build apk --release`).

Note: This zip intentionally contains only the Dart source + pubspec. Run `flutter create .` to generate platform folders before building.
