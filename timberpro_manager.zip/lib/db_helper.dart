import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'models/wood.dart';
import 'models/furniture.dart';
import 'package:uuid/uuid.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._internal();
  factory DBHelper() => _instance;
  DBHelper._internal();

  static Database? _db;
  final _uuid = Uuid();

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await initDb();
    return _db!;
  }

  Future<Database> initDb() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, 'timberpro.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE woods(
        id TEXT PRIMARY KEY,
        name TEXT,
        purchase_price REAL,
        sale_price REAL,
        min_sale_price REAL,
        quantity REAL,
        updated_at INTEGER
      )
    ''');
    await db.execute('''
      CREATE TABLE furniture(
        id TEXT PRIMARY KEY,
        name TEXT,
        category TEXT,
        photo_uri TEXT,
        purchase_price REAL,
        sale_price REAL,
        min_sale_price REAL,
        quantity REAL,
        created_at INTEGER,
        updated_at INTEGER
      )
    ''');

    // seed demo data
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.insert('woods', {
      'id': _uuid.v4(),
      'name': 'Teak',
      'purchase_price': 1200,
      'sale_price': 1600,
      'min_sale_price': 1400,
      'quantity': 50,
      'updated_at': now
    });
    await db.insert('woods', {
      'id': _uuid.v4(),
      'name': 'Mango',
      'purchase_price': 600,
      'sale_price': 850,
      'min_sale_price': 750,
      'quantity': 120,
      'updated_at': now
    });
    await db.insert('furniture', {
      'id': _uuid.v4(),
      'name': 'Classic Teak Door',
      'category': 'Door',
      'photo_uri': null,
      'purchase_price': 8000,
      'sale_price': 12000,
      'min_sale_price': 10000,
      'quantity': 10,
      'created_at': now,
      'updated_at': now
    });
  }

  // Woods CRUD
  Future<List<Wood>> getAllWoods() async {
    final dbClient = await db;
    final res = await dbClient.query('woods', orderBy: 'name');
    return res.map((e) => Wood.fromMap(e)).toList();
  }

  Future<int> insertWood(Wood w) async {
    final dbClient = await db;
    return await dbClient.insert('woods', w.toMap());
  }

  Future<int> updateWood(Wood w) async {
    final dbClient = await db;
    return await dbClient.update('woods', w.toMap(), where: 'id=?', whereArgs: [w.id]);
  }

  Future<int> deleteWood(String id) async {
    final dbClient = await db;
    return await dbClient.delete('woods', where: 'id=?', whereArgs: [id]);
  }

  // Furniture CRUD
  Future<List<Furniture>> getAllFurniture() async {
    final dbClient = await db;
    final res = await dbClient.query('furniture', orderBy: 'created_at DESC');
    return res.map((e) => Furniture.fromMap(e)).toList();
  }

  Future<int> insertFurniture(Furniture f) async {
    final dbClient = await db;
    return await dbClient.insert('furniture', f.toMap());
  }

  Future<int> updateFurniture(Furniture f) async {
    final dbClient = await db;
    return await dbClient.update('furniture', f.toMap(), where: 'id=?', whereArgs: [f.id]);
  }

  Future<int> deleteFurniture(String id) async {
    final dbClient = await db;
    return await dbClient.delete('furniture', where: 'id=?', whereArgs: [id]);
  }
}
