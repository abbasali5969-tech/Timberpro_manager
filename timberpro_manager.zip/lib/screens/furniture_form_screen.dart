import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';
import '../models/furniture.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class FurnitureFormScreen extends StatefulWidget {
  final Furniture? edit;
  FurnitureFormScreen({this.edit});
  @override
  _FurnitureFormScreenState createState() => _FurnitureFormScreenState();
}

class _FurnitureFormScreenState extends State<FurnitureFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtl = TextEditingController();
  final _categoryCtl = TextEditingController(text: 'Door');
  final _purchaseCtl = TextEditingController();
  final _saleCtl = TextEditingController();
  final _minCtl = TextEditingController();
  final _qtyCtl = TextEditingController();
  String? _photoPath;

  @override
  void initState() {
    super.initState();
    if (widget.edit != null) {
      _nameCtl.text = widget.edit!.name;
      _categoryCtl.text = widget.edit!.category;
      _purchaseCtl.text = widget.edit!.purchasePrice.toString();
      _saleCtl.text = widget.edit!.salePrice.toString();
      _minCtl.text = widget.edit!.minSalePrice.toString();
      _qtyCtl.text = widget.edit!.quantity.toString();
      _photoPath = widget.edit!.photoUri;
    }
  }

  Future<void> _pickImage() async {
    final img = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 75);
    if (img != null) setState(() => _photoPath = img.path);
  }

  Future<void> _takePhoto() async {
    final img = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 75);
    if (img != null) setState(() => _photoPath = img.path);
  }

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<InventoryProvider>(context, listen:false);
    final isEdit = widget.edit != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Furniture' : 'Add Furniture')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: ListView(children: [
            TextFormField(controller: _nameCtl, decoration: InputDecoration(labelText:'Name'), validator: (v)=> v==null||v.isEmpty ? 'required' : null),
            TextFormField(controller: _categoryCtl, decoration: InputDecoration(labelText:'Category')),
            Row(children: [
              ElevatedButton(onPressed: _pickImage, child: Text('Pick Image')),
              SizedBox(width:8),
              ElevatedButton(onPressed: _takePhoto, child: Text('Take Photo')),
            ]),
            if (_photoPath != null) Padding(padding: EdgeInsets.symmetric(vertical:8), child: Image.file(File(_photoPath!), height: 160)),
            TextFormField(controller: _purchaseCtl, decoration: InputDecoration(labelText:'Purchase Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _saleCtl, decoration: InputDecoration(labelText:'Sale Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _minCtl, decoration: InputDecoration(labelText:'Minimum Sale Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _qtyCtl, decoration: InputDecoration(labelText:'Quantity'), keyboardType: TextInputType.number),
            SizedBox(height:12),
            ElevatedButton(
              onPressed: () async {
                if (!_formKey.currentState!.validate()) return;
                final name = _nameCtl.text;
                final category = _categoryCtl.text;
                final purchase = double.tryParse(_purchaseCtl.text) ?? 0;
                final sale = double.tryParse(_saleCtl.text) ?? 0;
                final min = double.tryParse(_minCtl.text) ?? 0;
                final qty = double.tryParse(_qtyCtl.text) ?? 0;
                if (isEdit) {
                  final f = widget.edit!;
                  f.name = name; f.category = category; f.photoUri = _photoPath; f.purchasePrice = purchase; f.salePrice = sale; f.minSalePrice = min; f.quantity = qty;
                  await prov.updateFurniture(f);
                } else {
                  await prov.addFurniture(name, category, _photoPath, purchase, sale, min, qty);
                }
                Navigator.pop(context);
              },
              child: Text('Save'),
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF8B5A2B)),
            )
          ]),
        ),
      ),
    );
  }
}
