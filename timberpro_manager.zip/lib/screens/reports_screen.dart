import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:share_plus/share_plus.dart';

class ReportsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<InventoryProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Reports')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            ElevatedButton(onPressed: () async {
              final rows = <List<dynamic>>[];
              rows.add(['Type','Name','UnitProfit','Quantity','TotalProfit']);
              for (final w in prov.woods) {
                final unit = (w.salePrice - w.purchasePrice);
                rows.add(['Wood', w.name, unit, w.quantity, unit * w.quantity]);
              }
              for (final f in prov.furniture) {
                final unit = (f.salePrice - f.purchasePrice);
                rows.add(['Furniture', f.name, unit, f.quantity, unit * f.quantity]);
              }
              final csv = const ListToCsvConverter().convert(rows);
              final dir = await getApplicationDocumentsDirectory();
              final path = '${dir.path}/timber_report.csv';
              final file = File(path);
              await file.writeAsString(csv);
              await Share.shareFiles([path], text: 'TimberPro Report');
            }, child: Text('Export CSV')),
            SizedBox(height:12),
            Text('Quick Summary (open CSV for full details)'),
            SizedBox(height:8),
            Text('Total Woods: ${prov.woods.length}'),
            Text('Total Furniture: ${prov.furniture.length}'),
          ],
        ),
      ),
    );
  }
}
