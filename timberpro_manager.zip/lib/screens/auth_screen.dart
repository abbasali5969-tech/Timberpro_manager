import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthScreen extends StatefulWidget {
  @override
  _AuthScreenState createState() => _AuthScreenState();
}
class _AuthScreenState extends State<AuthScreen> {
  final _storage = FlutterSecureStorage();
  final _localAuth = LocalAuthentication();
  final _pinController = TextEditingController();
  bool hasPin = false;

  @override
  void initState() {
    super.initState();
    _checkPin();
  }

  Future<void> _checkPin() async {
    final pin = await _storage.read(key: 'timber_pin');
    setState(() { hasPin = pin != null; });
    if (pin != null) {
      final can = await _localAuth.canCheckBiometrics;
      if (can) {
        try {
          final ok = await _localAuth.authenticate(localizedReason: 'Authenticate to TimberPro');
          if (ok) Navigator.pushReplacementNamed(context, '/dashboard');
        } catch (e) { /* ignore */ }
      }
    }
  }

  Future<void> _setPin() async {
    if (_pinController.text.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Enter 4+ digit PIN')));
      return;
    }
    await _storage.write(key: 'timber_pin', value: _pinController.text);
    Navigator.pushReplacementNamed(context, '/dashboard');
  }

  Future<void> _login() async {
    final stored = await _storage.read(key: 'timber_pin');
    if (stored == _pinController.text) Navigator.pushReplacementNamed(context, '/dashboard');
    else ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Wrong PIN')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('TimberPro Manager')),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            SizedBox(height:20),
            Text('Enter 4-digit PIN', style: TextStyle(fontSize:18)),
            TextField(controller: _pinController, keyboardType: TextInputType.number, obscureText: true),
            SizedBox(height:20),
            ElevatedButton(
              onPressed: hasPin ? _login : _setPin,
              child: Text(hasPin ? 'Unlock' : 'Set PIN & Continue')
            )
          ],
        ),
      ),
    );
  }
}
