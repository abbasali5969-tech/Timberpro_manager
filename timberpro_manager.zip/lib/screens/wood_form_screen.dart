import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';
import '../models/wood.dart';
import 'package:uuid/uuid.dart';

class WoodFormScreen extends StatefulWidget {
  final Wood? edit;
  WoodFormScreen({this.edit});
  @override
  _WoodFormScreenState createState() => _WoodFormScreenState();
}

class _WoodFormScreenState extends State<WoodFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtl = TextEditingController();
  final _purchaseCtl = TextEditingController();
  final _saleCtl = TextEditingController();
  final _minCtl = TextEditingController();
  final _qtyCtl = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.edit != null) {
      _nameCtl.text = widget.edit!.name;
      _purchaseCtl.text = widget.edit!.purchasePrice.toString();
      _saleCtl.text = widget.edit!.salePrice.toString();
      _minCtl.text = widget.edit!.minSalePrice.toString();
      _qtyCtl.text = widget.edit!.quantity.toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<InventoryProvider>(context, listen:false);
    final isEdit = widget.edit != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Wood' : 'Add Wood')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: ListView(children: [
            TextFormField(controller: _nameCtl, decoration: InputDecoration(labelText:'Wood Name'), validator: (v)=> v==null||v.isEmpty ? 'required' : null),
            TextFormField(controller: _purchaseCtl, decoration: InputDecoration(labelText:'Purchase Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _saleCtl, decoration: InputDecoration(labelText:'Sale Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _minCtl, decoration: InputDecoration(labelText:'Minimum Sale Price'), keyboardType: TextInputType.number),
            TextFormField(controller: _qtyCtl, decoration: InputDecoration(labelText:'Quantity'), keyboardType: TextInputType.number),
            SizedBox(height:12),
            ElevatedButton(
              onPressed: () async {
                if (!_formKey.currentState!.validate()) return;
                final name = _nameCtl.text;
                final purchase = double.tryParse(_purchaseCtl.text) ?? 0;
                final sale = double.tryParse(_saleCtl.text) ?? 0;
                final min = double.tryParse(_minCtl.text) ?? 0;
                final qty = double.tryParse(_qtyCtl.text) ?? 0;
                if (isEdit) {
                  final w = widget.edit!;
                  w.name = name; w.purchasePrice = purchase; w.salePrice = sale; w.minSalePrice = min; w.quantity = qty;
                  await prov.updateWood(w);
                } else {
                  await prov.addWood(name, purchase, sale, min, qty);
                }
                Navigator.pop(context);
              },
              child: Text('Save'),
              style: ElevatedButton.styleFrom(backgroundColor: Color(0xFF8B5A2B)),
            )
          ]),
        ),
      ),
    );
  }
}
