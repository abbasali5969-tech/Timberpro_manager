import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<InventoryProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Dashboard')),
      body: RefreshIndicator(
        onRefresh: prov.refresh,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Overview', style: TextStyle(fontSize:22, fontWeight: FontWeight.bold, color: Color(0xFF6B4226))),
              SizedBox(height:12),
              Row(
                children: [
                  _statCard('Woods', prov.woods.length.toString()),
                  SizedBox(width:8),
                  _statCard('Furniture', prov.furniture.length.toString()),
                  SizedBox(width:8),
                  _statCard('Profit', '—') // compute later
                ],
              ),
              SizedBox(height:20),
              ElevatedButton(onPressed: ()=>Navigator.pushNamed(context,'/addWood'), child: Text('Add Wood')),
              ElevatedButton(onPressed: ()=>Navigator.pushNamed(context,'/addFurn'), child: Text('Add Furniture')),
              SizedBox(height:12),
              Text('Quick Access', style: TextStyle(fontWeight: FontWeight.bold)),
              ListTile(title: Text('Manage Woods'), trailing: Icon(Icons.chevron_right), onTap: ()=>Navigator.pushNamed(context,'/woods')),
              ListTile(title: Text('Manage Furniture'), trailing: Icon(Icons.chevron_right), onTap: ()=>Navigator.pushNamed(context,'/furn')),
              ListTile(title: Text('Reports'), trailing: Icon(Icons.chevron_right), onTap: ()=>Navigator.pushNamed(context,'/reports')),
            ],
          ),
        ),
      ),
    );
  }

  Widget _statCard(String title, String value) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
        child: Column(children: [Text(value, style: TextStyle(fontSize:20, fontWeight: FontWeight.bold, color: Color(0xFF8B5A2B))), SizedBox(height:6), Text(title)]),
      ),
    );
  }
}
