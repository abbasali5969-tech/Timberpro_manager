import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';
import '../models/wood.dart';
import 'wood_form_screen.dart';

class WoodListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<InventoryProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Wood Management')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: TextField(
              decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by name or price', border: OutlineInputBorder()),
              onChanged: (v) { /* implement filter stateful if you want */ },
            ),
          ),
          Expanded(
            child: prov.woods.isEmpty
                ? Center(child: Text('No woods yet'))
                : ListView.builder(
                    itemCount: prov.woods.length,
                    itemBuilder: (_, i) {
                      final Wood w = prov.woods[i];
                      final margin = (w.salePrice - w.purchasePrice).toStringAsFixed(2);
                      return Card(
                        margin: EdgeInsets.symmetric(horizontal:12, vertical:6),
                        child: ListTile(
                          title: Text(w.name),
                          subtitle: Text('Purchase: ₹${w.purchasePrice} | Sale: ₹${w.salePrice} | Min: ₹${w.minSalePrice}\nQty: ${w.quantity} | Margin: ₹$margin'),
                          isThreeLine: true,
                          trailing: PopupMenuButton<String>(
                            onSelected: (val) async {
                              if (val == 'edit') {
                                Navigator.push(context, MaterialPageRoute(builder: (_) => WoodFormScreen(edit: w)));
                              } else if (val == 'del') {
                                await prov.deleteWood(w.id);
                              }
                            },
                            itemBuilder: (_) => [
                              PopupMenuItem(value: 'edit', child: Text('Edit')),
                              PopupMenuItem(value: 'del', child: Text('Delete')),
                            ],
                          ),
                        ),
                      );
                    }),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: ()=> Navigator.pushNamed(context,'/addWood'),
        backgroundColor: Color(0xFF8B5A2B),
        child: Icon(Icons.add),
      ),
    );
  }
}
