import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/inventory_provider.dart';
import '../models/furniture.dart';
import 'furniture_form_screen.dart';
import 'dart:io';

class FurnitureListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final prov = Provider.of<InventoryProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Furniture')),
      body: prov.furniture.isEmpty
          ? Center(child: Text('No furniture yet'))
          : GridView.builder(
              padding: EdgeInsets.all(8),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 0.8),
              itemCount: prov.furniture.length,
              itemBuilder: (_, i) {
                final f = prov.furniture[i];
                return Card(
                  child: InkWell(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FurnitureFormScreen(edit: f))),
                    child: Column(
                      children: [
                        if (f.photoUri != null) Image.file(File(f.photoUri!), width: double.infinity, height: 100, fit: BoxFit.cover) else Container(height:100, color: Color(0xFFEFE1D6), child: Center(child: Text('No Image'))),
                        Padding(padding: EdgeInsets.all(8), child: Column(children: [Text(f.name, style: TextStyle(fontWeight: FontWeight.bold)), Text('₹${f.salePrice.toStringAsFixed(0)}')]))
                      ],
                    ),
                  ),
                );
              }),
      floatingActionButton: FloatingActionButton(
        onPressed: ()=> Navigator.pushNamed(context,'/addFurn'),
        backgroundColor: Color(0xFF8B5A2B),
        child: Icon(Icons.add),
      ),
    );
  }
}
