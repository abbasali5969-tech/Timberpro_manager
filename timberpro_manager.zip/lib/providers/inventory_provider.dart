import 'package:flutter/material.dart';
import '../db_helper.dart';
import '../models/wood.dart';
import '../models/furniture.dart';
import 'package:uuid/uuid.dart';

class InventoryProvider extends ChangeNotifier {
  final DBHelper _db = DBHelper();
  List<Wood> woods = [];
  List<Furniture> furniture = [];
  final _uuid = Uuid();

  Future<void> init() async {
    await _db.db;
    await refresh();
  }

  Future<void> refresh() async {
    woods = await _db.getAllWoods();
    furniture = await _db.getAllFurniture();
    notifyListeners();
  }

  Future<void> addWood(String name, double purchase, double sale, double minSale, double qty) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final w = Wood(
      id: _uuid.v4(),
      name: name,
      purchasePrice: purchase,
      salePrice: sale,
      minSalePrice: minSale,
      quantity: qty,
      updatedAt: now,
    );
    await _db.insertWood(w);
    await refresh();
  }

  Future<void> updateWood(Wood w) async {
    w.updatedAt = DateTime.now().millisecondsSinceEpoch;
    await _db.updateWood(w);
    await refresh();
  }

  Future<void> deleteWood(String id) async {
    await _db.deleteWood(id);
    await refresh();
  }

  Future<void> addFurniture(String name, String category, String? photo, double purchase, double sale, double minSale, double qty) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final f = Furniture(
      id: _uuid.v4(),
      name: name,
      category: category,
      photoUri: photo,
      purchasePrice: purchase,
      salePrice: sale,
      minSalePrice: minSale,
      quantity: qty,
      createdAt: now,
      updatedAt: now
    );
    await _db.insertFurniture(f);
    await refresh();
  }

  Future<void> updateFurniture(Furniture f) async {
    f.updatedAt = DateTime.now().millisecondsSinceEpoch;
    await _db.updateFurniture(f);
    await refresh();
  }

  Future<void> deleteFurniture(String id) async {
    await _db.deleteFurniture(id);
    await refresh();
  }
}
