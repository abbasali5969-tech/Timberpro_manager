import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/inventory_provider.dart';
import 'screens/auth_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/wood_list_screen.dart';
import 'screens/furniture_list_screen.dart';
import 'screens/reports_screen.dart';
import 'screens/wood_form_screen.dart';
import 'screens/furniture_form_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(TimberProApp());
}

class TimberProApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => InventoryProvider()..init(),
      child: MaterialApp(
        title: 'TimberPro Manager',
        theme: ThemeData(
          primaryColor: Color(0xFF8B5A2B),
          scaffoldBackgroundColor: Color(0xFFFFFDF7),
          appBarTheme: AppBarTheme(
            backgroundColor: Color(0xFF8B5A2B),
            foregroundColor: Colors.white,
          ),
        ),
        home: AuthScreen(),
        routes: {
          '/dashboard': (_) => DashboardScreen(),
          '/woods': (_) => WoodListScreen(),
          '/furn': (_) => FurnitureListScreen(),
          '/reports': (_) => ReportsScreen(),
          '/addWood': (_) => WoodFormScreen(),
          '/addFurn': (_) => FurnitureFormScreen(),
        },
      ),
    );
  }
}
