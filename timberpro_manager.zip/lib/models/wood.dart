class Wood {
  final String id;
  String name;
  double purchasePrice;
  double salePrice;
  double minSalePrice;
  double quantity;
  int updatedAt;

  Wood({
    required this.id,
    required this.name,
    required this.purchasePrice,
    required this.salePrice,
    required this.minSalePrice,
    required this.quantity,
    required this.updatedAt,
  });

  factory Wood.fromMap(Map<String, dynamic> m) => Wood(
    id: m['id'],
    name: m['name'],
    purchasePrice: (m['purchase_price'] ?? 0).toDouble(),
    salePrice: (m['sale_price'] ?? 0).toDouble(),
    minSalePrice: (m['min_sale_price'] ?? 0).toDouble(),
    quantity: (m['quantity'] ?? 0).toDouble(),
    updatedAt: m['updated_at'] ?? 0,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'purchase_price': purchasePrice,
    'sale_price': salePrice,
    'min_sale_price': minSalePrice,
    'quantity': quantity,
    'updated_at': updatedAt,
  };
}
