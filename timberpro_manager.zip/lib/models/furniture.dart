class Furniture {
  final String id;
  String name;
  String category;
  String? photoUri;
  double purchasePrice;
  double salePrice;
  double minSalePrice;
  double quantity;
  int createdAt;
  int updatedAt;

  Furniture({
    required this.id,
    required this.name,
    required this.category,
    this.photoUri,
    required this.purchasePrice,
    required this.salePrice,
    required this.minSalePrice,
    required this.quantity,
    required this.createdAt,
    required this.updatedAt,
  });

  factory Furniture.fromMap(Map<String, dynamic> m) => Furniture(
    id: m['id'],
    name: m['name'],
    category: m['category'],
    photoUri: m['photo_uri'],
    purchasePrice: (m['purchase_price'] ?? 0).toDouble(),
    salePrice: (m['sale_price'] ?? 0).toDouble(),
    minSalePrice: (m['min_sale_price'] ?? 0).toDouble(),
    quantity: (m['quantity'] ?? 0).toDouble(),
    createdAt: m['created_at'] ?? 0,
    updatedAt: m['updated_at'] ?? 0,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'category': category,
    'photo_uri': photoUri,
    'purchase_price': purchasePrice,
    'sale_price': salePrice,
    'min_sale_price': minSalePrice,
    'quantity': quantity,
    'created_at': createdAt,
    'updated_at': updatedAt,
  };
}
